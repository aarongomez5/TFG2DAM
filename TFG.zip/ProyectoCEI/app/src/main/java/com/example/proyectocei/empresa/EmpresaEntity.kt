package com.example.proyectocei.empresa

data class EmpresaEntity(
    var id: Long = 0,
    var logo: String
)
